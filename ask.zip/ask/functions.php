<?php
/**
 * ASK Scrubs child theme.
 */

const ASK_FREE_DELIVERY = 6000; // KSh, keep in step with the Free Nairobi Express Delivery shipping method.
const ASK_EMBROIDERY    = 500;  // KSh added per embroidered item.
const ASK_WHATSAPP      = '254110433305';
const ASK_LOW_STOCK     = 3;
const ASK_EMBROIDER_CATS = [ 'scrubs', 'jogger-scrubs', 'scrub-jackets', 'lab-coats', 'nurse-uniforms' ];

require __DIR__ . '/seo.php';

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'ask-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap', [], null );
	wp_enqueue_style( 'ask', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'ask', $uri . '/assets/ask.js', [], filemtime( $dir . '/assets/ask.js' ), true );
	wp_localize_script( 'ask', 'ASK', [
		'freeAt'    => ASK_FREE_DELIVERY,
		'store'     => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'      => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'ask-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap', [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

/* -------------------------------------------------------------------------
 * Colours and sizes
 * ---------------------------------------------------------------------- */

/**
 * Swatch colour for a colour name. Anything unknown gets a neutral grey.
 */
function ask_colour_css( $name ) {
	$map = [
		'royal blue'   => '#1F4FB5',
		'navy blue'    => '#1B2A4A',
		'ceil blue'    => '#8FB3D9',
		'sky blue'     => '#6EC1E4',
		'galaxy blue'  => '#2A3F8F',
		'blue'         => '#1F6FD1',
		'wine'         => '#6D1F3B',
		'maroon'       => '#6D1F3B',
		'purple'       => '#5B2A86',
		'surgical green' => '#0F7A5C',
		'hunter green' => '#1F5A3A',
		'green'        => '#2E9E5B',
		'teal'         => '#127C82',
		'mint'         => '#A8DCCB',
		'charcoal'     => '#3D4248',
		'gray'         => '#9AA3AD',
		'grey'         => '#9AA3AD',
		'black'        => '#15171A',
		'white'        => '#FFFFFF',
		'red'          => '#C62839',
		'magenta'      => '#C2185B',
		'coral pink'   => '#F28C82',
		'eggplant'     => '#4A2545',
		'plum'         => '#7B1F5E',
		'lilac'        => '#B9A2D6',
		'mustard'      => '#D9A21B',
		'olive'        => '#5E6B4E',
		'seafoam'      => '#6CC7B5',
		'pewter'       => '#6B7078',
		'yellow'       => '#F2C230',
		'bottle green' => '#0F5132',
		'cream'        => '#F3E9D2',
		'assorted'     => 'conic-gradient(#E4572E 0 25%,#1F4FB5 0 50%,#2E9E5B 0 75%,#F2C230 0)',
		'pink'         => '#F4A7C0',
		'orange'       => '#F07A1A',
		'gold'         => '#C9A43A',
		'silver'       => '#C0C4C9',
		'white & navy' => 'linear-gradient(135deg,#fff 50%,#1B2A4A 50%)',
		'printed'      => 'conic-gradient(#F4A7C0 0 25%,#8FB3D9 0 50%,#A8DCCB 0 75%,#F0C987 0)',
	];
	return $map[ strtolower( trim( html_entity_decode( $name ) ) ) ] ?? '#B8C2CC';
}

/**
 * Colour/size options a shopper chooses on the product page (attributes that are not variations).
 *
 * @return array{colour: WP_Term[], size: WP_Term[]}
 */
function ask_choices( WC_Product $product ) {
	$out = [ 'colour' => [], 'size' => [] ];
	$attrs = $product->get_attributes();
	foreach ( [ 'colour', 'size' ] as $key ) {
		$tax = "pa_$key";
		if ( isset( $attrs[ $tax ] ) && ! $attrs[ $tax ]->get_variation() ) {
			$out[ $key ] = wc_get_product_terms( $product->get_id(), $tax, [ 'orderby' => 'menu_order' ] );
		}
	}
	return $out;
}

function ask_can_embroider( WC_Product $product ) {
	return has_term( ASK_EMBROIDER_CATS, 'product_cat', $product->get_id() );
}

function ask_needs_choices( WC_Product $product ) {
	$c = ask_choices( $product );
	return $product->is_type( 'variable' ) || $c['colour'] || $c['size'];
}

/* -------------------------------------------------------------------------
 * Product page: swatches, sizes, embroidery
 * ---------------------------------------------------------------------- */

add_action( 'woocommerce_before_add_to_cart_quantity', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$c = ask_choices( $product );

	if ( $c['colour'] ) {
		$single = count( $c['colour'] ) === 1;
		echo '<fieldset class="ask-opt ask-opt--colour"><legend>Colour: <strong data-ask-colour-label>' . ( $single ? esc_html( $c['colour'][0]->name ) : 'choose one' ) . '</strong></legend><div class="ask-swatches">';
		// Which gallery photo shows each colour (0 = main photo), set per product.
		$photos = (array) $product->get_meta( '_ask_colour_images' );
		foreach ( $c['colour'] as $t ) {
			printf(
				'<label class="ask-swatch" title="%1$s"><input type="radio" name="ask_colour" value="%1$s" required%3$s%4$s><span style="background:%2$s"></span><em class="screen-reader-text">%1$s</em></label>',
				esc_attr( $t->name ),
				esc_attr( ask_colour_css( $t->name ) ),
				$single ? ' checked' : '',
				isset( $photos[ $t->name ] ) ? ' data-ask-photo="' . (int) $photos[ $t->name ] . '"' : ''
			);
		}
		echo '</div></fieldset>';
	}

	if ( $c['size'] ) {
		echo '<fieldset class="ask-opt ask-opt--size"><legend>Size: <strong data-ask-size-label>choose one</strong>';
		if ( ! has_term( [ 'footwear' ], 'product_cat', $product->get_id() ) ) {
			echo ' <button type="button" class="ask-link" data-ask-open="ask-size-guide">Size guide</button>';
		}
		echo '</legend><div class="ask-sizes">';
		foreach ( $c['size'] as $t ) {
			printf( '<label class="ask-size"><input type="radio" name="ask_size" value="%1$s" required><span>%1$s</span></label>', esc_attr( $t->name ) );
		}
		echo '</div></fieldset>';
	}

	if ( ask_can_embroider( $product ) ) {
		?>
		<div class="ask-emb" data-ask-emb>
			<label class="ask-emb__toggle"><input type="checkbox" name="ask_emb" value="1" data-ask-emb-toggle>
				<span><strong>Add name embroidery</strong> <em>+ KSh <?php echo number_format( ASK_EMBROIDERY ); ?></em><small>Your name and title stitched on the chest</small></span>
			</label>
			<div class="ask-emb__fields" hidden>
				<label>Name &amp; qualifications<input type="text" name="ask_emb_text" maxlength="30" placeholder="e.g. Dr. S. Wanjiru, MBChB" data-ask-emb-text></label>
				<div class="ask-emb__row">
					<label>Thread colour<select name="ask_emb_thread" data-ask-emb-thread>
						<?php foreach ( [ 'White', 'Navy', 'Black', 'Gold', 'Sky Blue', 'Royal Blue' ] as $t ) echo '<option>' . esc_html( $t ) . '</option>'; ?>
					</select></label>
					<label>Position<select name="ask_emb_side" data-ask-emb-side><option>Left chest</option><option>Right chest</option></select></label>
				</div>
				<div class="ask-emb__preview" data-ask-emb-preview><span>Your name here</span></div>
			</div>
		</div>
		<?php
	}
} );

// Size guide pop-up on product pages, and as a page of its own.
function ask_size_guide_html() {
	$rows = [
		[ 'XS', '82–87', '66–71', '68' ],
		[ 'S', '88–93', '72–77', '70' ],
		[ 'M', '94–100', '78–84', '72' ],
		[ 'L', '101–108', '85–92', '74' ],
		[ 'XL', '109–116', '93–100', '76' ],
		[ '2XL', '117–124', '101–108', '78' ],
		[ '3XL', '125–132', '109–116', '80' ],
	];
	$h = '<div class="ask-size-table"><table><thead><tr><th>Size</th><th>Chest (cm)</th><th>Waist (cm)</th><th>Top length (cm)</th></tr></thead><tbody>';
	foreach ( $rows as $r ) {
		$h .= '<tr><td><strong>' . $r[0] . '</strong></td><td>' . $r[1] . '</td><td>' . $r[2] . '</td><td>' . $r[3] . '</td></tr>';
	}
	$h .= '</tbody></table></div>';
	$h .= '<p class="ask-small">Scrubs and jackets are unisex. Measure around the fullest part of your chest and your natural waist. Between sizes? Go one up for a relaxed fit, or pop into the shop and try both.</p>';
	return $h;
}
add_shortcode( 'ask_size_guide', 'ask_size_guide_html' );

add_action( 'wp_footer', function () {
	if ( ! is_product() ) {
		return;
	}
	echo '<dialog id="ask-size-guide" class="ask-dialog"><form method="dialog"><button class="ask-dialog__close" aria-label="Close">×</button></form><h2>Size guide</h2>' . ask_size_guide_html() . '</dialog>';
} );

add_filter( 'woocommerce_add_to_cart_validation', function ( $ok, $product_id ) {
	$product = wc_get_product( $product_id );
	if ( ! $product ) {
		return $ok;
	}
	$c = ask_choices( $product );
	if ( count( $c['colour'] ) > 1 && empty( $_REQUEST['ask_colour'] ) ) {
		wc_add_notice( 'Please choose a colour.', 'error' );
		return false;
	}
	if ( $c['size'] && empty( $_REQUEST['ask_size'] ) ) {
		wc_add_notice( 'Please choose a size.', 'error' );
		return false;
	}
	if ( ! empty( $_REQUEST['ask_emb'] ) && trim( wp_unslash( $_REQUEST['ask_emb_text'] ?? '' ) ) === '' ) {
		wc_add_notice( 'Please enter the name to embroider, or untick embroidery.', 'error' );
		return false;
	}
	return $ok;
}, 10, 2 );

add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	$product = wc_get_product( $product_id );
	if ( ! $product ) {
		return $data;
	}
	$c = ask_choices( $product );
	$clean = fn( $k ) => sanitize_text_field( wp_unslash( $_REQUEST[ $k ] ?? '' ) );
	if ( $c['colour'] ) {
		$data['ask_colour'] = $clean( 'ask_colour' ) ?: $c['colour'][0]->name;
	}
	if ( $c['size'] && $clean( 'ask_size' ) ) {
		$data['ask_size'] = $clean( 'ask_size' );
	}
	if ( ! empty( $_REQUEST['ask_emb'] ) && ask_can_embroider( $product ) ) {
		$data['ask_emb'] = [
			'text'   => mb_substr( $clean( 'ask_emb_text' ), 0, 30 ),
			'thread' => $clean( 'ask_emb_thread' ) ?: 'White',
			'side'   => $clean( 'ask_emb_side' ) ?: 'Left chest',
		];
	}
	return $data;
}, 10, 2 );

function ask_item_lines( array $item ) {
	$lines = [];
	if ( ! empty( $item['ask_colour'] ) ) $lines['Colour'] = $item['ask_colour'];
	if ( ! empty( $item['ask_size'] ) ) $lines['Size'] = $item['ask_size'];
	if ( ! empty( $item['ask_emb'] ) ) {
		$e = $item['ask_emb'];
		$lines['Embroidery'] = '"' . $e['text'] . '" – ' . $e['thread'] . ' thread, ' . strtolower( $e['side'] ) . ' (+KSh ' . number_format( ASK_EMBROIDERY ) . ')';
	}
	return $lines;
}

add_filter( 'woocommerce_get_item_data', function ( $out, $item ) {
	foreach ( ask_item_lines( $item ) as $k => $v ) {
		$out[] = [ 'key' => $k, 'value' => $v ];
	}
	return $out;
}, 10, 2 );

add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	foreach ( $cart->get_cart() as $item ) {
		if ( empty( $item['ask_emb'] ) ) {
			continue;
		}
		$fresh = wc_get_product( $item['variation_id'] ?: $item['product_id'] );
		if ( $fresh ) {
			$item['data']->set_price( (float) $fresh->get_price() + ASK_EMBROIDERY );
		}
	}
}, 20 );

add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $item ) {
	foreach ( ask_item_lines( $item ) as $k => $v ) {
		$line->add_meta_data( $k, $v );
	}
}, 10, 3 );

// "Complete the set": the product's upsells, under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$ids = array_slice( $product->get_upsell_ids(), 0, 3 );
	if ( ! $ids ) {
		return;
	}
	echo '<div class="ask-set"><p class="ask-set__title">Complete the set</p>';
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p || ! $p->is_visible() ) continue;
		printf(
			'<a class="ask-set__item" href="%s">%s<span><strong>%s</strong>%s</span><em>View</em></a>',
			esc_url( $p->get_permalink() ),
			$p->get_image( 'thumbnail' ),
			esc_html( $p->get_name() ),
			$p->get_price_html()
		);
	}
	echo '</div>';
} );

/**
 * Product videos: one per line in the "Videos" field, either a file name in uploads/ask-videos
 * (e.g. "mint-scrubs-1") or a full URL to an .mp4. A .jpg with the same name is used as the poster.
 *
 * @return array<array{src: string, poster: string}>
 */
function ask_product_videos( WC_Product $product ) {
	$lines = array_filter( array_map( 'trim', explode( "\n", (string) $product->get_meta( '_ask_videos' ) ) ) );
	$base  = get_option( 'ask_video_base' ) ?: wp_upload_dir()['baseurl'] . '/ask-videos/';
	$out   = [];
	foreach ( $lines as $line ) {
		$src = preg_match( '#^https?://#', $line ) ? $line : trailingslashit( $base ) . preg_replace( '#\.mp4$#', '', $line ) . '.mp4';
		$out[] = [ 'src' => $src, 'poster' => preg_replace( '#\.mp4(\?.*)?$#', '.jpg', $src ) ];
	}
	return $out;
}

// Videos sit under the photo gallery on the product page.
add_filter( 'render_block_woocommerce/product-image-gallery', function ( $content ) {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return $content;
	}
	$videos = ask_product_videos( $product );
	if ( ! $videos ) {
		return $content;
	}
	$h = '<div class="ask-videos"><p class="ask-videos__title">Watch it in the shop <span>' . count( $videos ) . ( count( $videos ) > 1 ? ' videos' : ' video' ) . '</span></p><div class="ask-videos__row">';
	foreach ( $videos as $v ) {
		$h .= sprintf( '<video controls playsinline preload="none" poster="%s" src="%s"></video>', esc_url( $v['poster'] ), esc_url( $v['src'] ) );
	}
	return $content . $h . '</div></div>';
} );

// Fabric & care and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$fabric = get_post_meta( $product->get_id(), '_ask_fabric', true );
	if ( $fabric ) {
		$tabs['ask_fabric'] = [
			'title'    => 'Fabric & care',
			'priority' => 15,
			'callback' => function () use ( $fabric ) {
				echo wpautop( wp_kses_post( $fabric ) );
			},
		];
	}
	$tabs['ask_delivery'] = [
		'title'    => 'Delivery & pickup',
		'priority' => 25,
		'callback' => function () {
			echo '<ul><li><strong>Nairobi express:</strong> same-day dispatch for orders placed before 3 PM, KSh 300. Free on orders over KSh ' . number_format( ASK_FREE_DELIVERY ) . '.</li><li><strong>Upcountry courier:</strong> 1–3 days to any county, KSh 500.</li><li><strong>In-store pickup:</strong> free from Imenti House, Limoda Exhibition, Shop 4DW Basement, Tom Mboya Street. We\'ll call when it\'s ready.</li><li>Embroidered items are usually ready in 1–2 working days.</li></ul>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function ask_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo) and wishlist heart on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = ask_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'ask-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$heart = sprintf(
		'<button type="button" class="ask-heart" data-ask-wish="%d" aria-label="Save %s to wishlist" aria-pressed="false"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg></button>',
		$product->get_id(),
		esc_attr( $product->get_name() )
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $heart . '</div>', $pos, 6 );
}, 10, 3 );

// Spec badge above the price, colour dots below it.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = ask_card_product( $instance );
	if ( ! $product ) {
		return $content;
	}
	$before = '';
	$spec = get_post_meta( $product->get_id(), '_ask_spec', true );
	if ( $spec ) {
		$before .= '<span class="ask-badge">' . esc_html( $spec ) . '</span>';
	}
	if ( ! $product->is_in_stock() ) {
		$before .= '<span class="ask-badge ask-badge--out">Out of stock</span>';
	} elseif ( $product->managing_stock() && (int) $product->get_stock_quantity() <= ASK_LOW_STOCK ) {
		$before .= '<span class="ask-badge ask-badge--low">Only ' . (int) $product->get_stock_quantity() . ' left</span>';
	}
	$after = '';
	if ( ! empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		$colours = ask_choices( $product )['colour'];
		if ( count( $colours ) > 1 ) {
			$after = '<div class="ask-dots" aria-label="' . count( $colours ) . ' colours">';
			foreach ( array_slice( $colours, 0, 7 ) as $t ) {
				$after .= '<span title="' . esc_attr( $t->name ) . '" style="background:' . esc_attr( ask_colour_css( $t->name ) ) . '"></span>';
			}
			if ( count( $colours ) > 7 ) {
				$after .= '<em>+' . ( count( $colours ) - 7 ) . '</em>';
			}
			$after .= '</div>';
		}
	}
	return ( $before ? '<div class="ask-badges">' . $before . '</div>' : '' ) . $content . $after;
}, 10, 3 );

// Products with options (full set / top only…) show the price of the default option, e.g.
// "KSh 3,000" for a full set, instead of a "KSh 1,200 – KSh 3,000" range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$default = $product->get_default_attributes();
	if ( ! $default ) {
		return $html;
	}
	$id = ( new WC_Product_Data_Store_CPT() )->find_matching_product_variation( $product, array_combine( array_map( fn( $k ) => 'attribute_' . $k, array_keys( $default ) ), $default ) );
	$variation = $id ? wc_get_product( $id ) : null;
	return $variation ? $variation->get_price_html() : $html;
}, 10, 2 );

// Sale badge shows the saving, e.g. "−18%".
add_filter( 'render_block_woocommerce/product-sale-badge', function ( $content, $block, $instance ) {
	$product = ask_card_product( $instance );
	if ( ! $product || ! $product->is_on_sale() ) {
		return $content;
	}
	$pct = 0;
	foreach ( $product->is_type( 'variable' ) ? $product->get_available_variations( 'objects' ) : [ $product ] as $p ) {
		$reg  = (float) $p->get_regular_price();
		$sale = (float) $p->get_sale_price();
		if ( $reg > 0 && $sale > 0 ) {
			$pct = max( $pct, round( ( $reg - $sale ) / $reg * 100 ) );
		}
	}
	return $pct ? preg_replace( '#>\s*Sale\s*<#', '>−' . $pct . '%<', $content, 1 ) : $content;
}, 10, 3 );

// Products that need a colour or size go to the product page instead of adding straight to the cart.
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	if ( $product->is_purchasable() && $product->is_in_stock() && ask_needs_choices( $product ) ) {
		return ask_choices( $product )['size'] ? 'Choose size' : 'Choose options';
	}
	return $text;
}, 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_url', function ( $url, $product ) {
	return ! is_product() && ask_needs_choices( $product ) ? $product->get_permalink() : $url;
}, 10, 2 );
add_filter( 'woocommerce_product_supports', function ( $supports, $feature, $product ) {
	return $feature === 'ajax_add_to_cart' && ask_needs_choices( $product ) ? false : $supports;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page sections
 * ---------------------------------------------------------------------- */

add_shortcode( 'ask_roles', function () {
	$roles = [
		'doctors-surgeons'  => [ 'Doctors & Surgeons', 'role-doctors' ],
		'nurses-midwives'   => [ 'Nurses & Midwives', 'role-nurses' ],
		'clinical-students' => [ 'Clinical Students', 'role-students' ],
		'dental-lab'        => [ 'Dental & Lab Staff', 'role-dental' ],
	];
	$h = '<div class="ask-roles">';
	foreach ( $roles as $slug => [ $name, $img ] ) {
		$term = get_term_by( 'slug', $slug, 'product_tag' );
		if ( ! $term ) continue;
		$h .= sprintf(
			'<a class="ask-role" href="%s"><img src="%s" alt="" loading="lazy" width="300" height="400"><span><strong>%s</strong><em>%d products</em></span></a>',
			esc_url( get_term_link( $term ) ),
			esc_url( get_stylesheet_directory_uri() . "/assets/photos/$img.webp" ),
			esc_html( $name ),
			(int) $term->count
		);
	}
	return $h . '</div>';
} );

add_shortcode( 'ask_colours', function () {
	$terms = get_terms( [ 'taxonomy' => 'pa_colour', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 12 ] );
	if ( is_wp_error( $terms ) || ! $terms ) {
		return '';
	}
	$h = '<div class="ask-colours"><p class="ask-colours__label">Shop by colour</p><div class="ask-colours__list">';
	foreach ( $terms as $t ) {
		$h .= sprintf(
			'<a href="%s"><span style="background:%s"></span>%s</a>',
			esc_url( get_term_link( $t ) ),
			esc_attr( ask_colour_css( $t->name ) ),
			esc_html( $t->name )
		);
	}
	return $h . '</div></div>';
} );

// Category and colour chips above shop, category, colour and search results.
add_shortcode( 'ask_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="ask-filters" aria-label="Filter products"><div class="ask-filters__row">';
	$h .= '<a class="ask-chip' . ( is_shop() ? ' is-on' : '' ) . '" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">All</a>';
	foreach ( get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'term_id' ] ) as $t ) {
		$h .= sprintf( '<a class="ask-chip%s" href="%s">%s <em>%d</em></a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ), (int) $t->count );
	}
	$h .= '</div><div class="ask-filters__row ask-filters__row--colours"><span>Colour</span>';
	foreach ( get_terms( [ 'taxonomy' => 'pa_colour', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 14 ] ) as $t ) {
		$h .= sprintf(
			'<a class="ask-colour-dot%s" href="%s" title="%s" aria-label="%3$s"><span style="background:%s"></span></a>',
			$t->term_id === $cur_id ? ' is-on' : '',
			esc_url( get_term_link( $t ) ),
			esc_attr( $t->name ),
			esc_attr( ask_colour_css( $t->name ) )
		);
	}
	return $h . '</div></nav>';
} );

add_shortcode( 'ask_wishlist', function () {
	return '<div class="ask-wishlist" data-ask-wishlist><p class="ask-small">Loading your saved items…</p></div>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function ask_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, ASK_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / ASK_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>KSh ' . number_format( $left ) . '</strong> more for <strong>free Nairobi express delivery</strong>'
		: '<strong>You\'ve unlocked free Nairobi express delivery!</strong>';
	return '<div class="ask-freebar" data-ask-freebar>' . $msg . '<div class="ask-freebar__track"><div class="ask-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => ask_freebar_html() . $c );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-filled-mini-cart-contents-block[^>]*>)#', '$1' . ask_freebar_html(), $c, 1 );
} );

// Designation at checkout, so the shop knows who it's dressing.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'ask/designation',
		'label'    => 'Role',
		'location' => 'contact',
		'type'     => 'select',
		'required' => false,
		'options'  => array_map( fn( $v ) => [ 'value' => $v, 'label' => $v ], [ 'Doctor', 'Nurse / Midwife', 'Clinical Officer', 'Medical Student', 'Dentist', 'Lab Technologist', 'Pharmacist', 'Other' ] ),
	] );
} );

// WhatsApp order summary on the order confirmation page.
function ask_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi ASK Scrubs, I just placed order #' . $order->get_order_number() . ':' ];
	foreach ( $order->get_items() as $item ) {
		$meta = [];
		foreach ( [ 'Colour', 'Size', 'Embroidery' ] as $k ) {
			$v = $item->get_meta( $k );
			if ( $v ) $meta[] = "$k: $v";
		}
		$lines[] = '• ' . $item->get_quantity() . ' × ' . $item->get_name() . ( $meta ? ' (' . implode( '; ', $meta ) . ')' : '' );
	}
	$lines[] = 'Total: KSh ' . number_format( (float) $order->get_total() );
	$lines[] = 'Delivery: ' . $order->get_shipping_method();
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return 'https://wa.me/' . ASK_WHATSAPP . '?text=' . rawurlencode( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="ask-thanks"><p>Your order number is <strong>#' . esc_html( $order->get_order_number() ) . '</strong>. Send us the summary on WhatsApp and we\'ll confirm it straight away.</p><a class="wp-element-button ask-wa-btn" href="' . esc_attr( ask_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">Send order on WhatsApp</a></div>';
} );

// Newsletter: store the email and hand over the KSh 500 welcome code.
add_action( 'admin_post_nopriv_ask_subscribe', 'ask_subscribe' );
add_action( 'admin_post_ask_subscribe', 'ask_subscribe' );
function ask_subscribe() {
	check_admin_referer( 'ask_subscribe' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$back  = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'ask_sub', 'invalid', $back ) . '#newsletter' );
		exit;
	}
	$list = get_option( 'ask_subscribers', [] );
	$list[ strtolower( $email ) ] = current_time( 'mysql' );
	update_option( 'ask_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'ask_sub', 'ok', $back ) . '#newsletter' );
	exit;
}

add_shortcode( 'ask_newsletter', function () {
	$state = sanitize_key( $_GET['ask_sub'] ?? '' );
	if ( $state === 'ok' ) {
		return '<p class="ask-news-ok"><strong>Welcome to the Med-Club!</strong> Use code <strong class="ask-cyan">MEDCLUB300</strong> at checkout for KSh 300 off your first order.</p>';
	}
	$err = $state === 'invalid' ? '<p class="ask-news-err">Please enter a valid email address.</p>' : '';
	return '<form class="ask-news-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="ask_subscribe">'
		. wp_nonce_field( 'ask_subscribe', '_wpnonce', true, false )
		. '<input type="email" name="email" required placeholder="Your email address" aria-label="Email address">'
		. '<button class="wp-element-button" type="submit">Get KSh 300 off</button>'
		. '</form>' . $err;
} );

// Staff see the subscriber list under WooCommerce.
add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'Med-Club subscribers', 'Subscribers', 'manage_woocommerce', 'ask-subscribers', function () {
		$list = get_option( 'ask_subscribers', [] );
		echo '<div class="wrap"><h1>Med-Club subscribers (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email</th><th>Signed up</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $email => $when ) {
			echo '<tr><td>' . esc_html( $email ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

// Staff edit the card badge and the fabric & care text on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_ask_spec', 'label' => 'Card badge', 'description' => 'Short label on the product card, e.g. "4-Way Stretch".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_ask_fabric', 'label' => 'Fabric & care', 'rows' => 5 ] );
	woocommerce_wp_textarea_input( [ 'id' => '_ask_videos', 'label' => 'Videos', 'rows' => 3, 'description' => 'One per line: paste the link of an .mp4 from the Media Library.', 'desc_tip' => true ] );
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_ask_spec' => 'sanitize_text_field', '_ask_fabric' => 'wp_kses_post', '_ask_videos' => 'sanitize_textarea_field' ] as $key => $clean ) {
		if ( isset( $_POST[ $key ] ) ) {
			$product->update_meta_data( $key, $clean( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and riders need a phone number.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate (e.g. Westlands, Kilimani)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon: the shop's logo.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );

// The shop shows no WordPress toolbar, version tags or discovery links. Staff work from /wp-admin.
add_filter( 'show_admin_bar', '__return_false' );
add_filter( 'the_generator', '__return_empty_string' );
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'emoji_svg_url', '__return_false' );
add_filter( 'wp_headers', function ( $headers ) {
	unset( $headers['X-Pingback'] );
	return $headers;
} );
add_action( 'init', function () {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'feed_links', 2 );
	remove_action( 'wp_head', 'feed_links_extra', 3 );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_footer_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'template_redirect', 'rest_output_link_header', 11 );
	remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
} );

// The staff login page carries the shop's logo instead of the WordPress one.
add_action( 'login_enqueue_scripts', function () {
	$logo = esc_url( get_stylesheet_directory_uri() . '/assets/logo.webp' );
	echo "<style>body.login #login h1 a{background:url($logo) center/contain no-repeat;width:160px;height:110px}#backtoblog,.language-switcher{display:none}</style>";
} );
add_filter( 'login_title', fn( $title ) => str_replace( [ ' &#8212; WordPress', ' — WordPress' ], '', $title ) );
add_filter( 'login_headerurl', fn() => home_url( '/' ) );
add_filter( 'login_headertext', fn() => 'ASK Scrubs' );

// Shop thumbnails match the 4:5 product cards (WooCommerce's default is a 300px square).
add_filter( 'woocommerce_get_image_size_thumbnail', function () {
	return [ 'width' => 480, 'height' => 600, 'crop' => 1 ];
} );
