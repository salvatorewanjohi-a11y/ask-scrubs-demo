<?php
/**
 * Search engines: page titles, descriptions, sharing tags, the shop's details for Google,
 * category introductions and a tidy sitemap.
 */

// Shown above the products on each category page, unless staff write their own description
// under Products → Categories.
const ASK_CAT_INTROS = [
	'scrubs'         => 'Medical scrub sets in Nairobi: stretchy Infinity sets, smooth mint-fabric sets and breathable cotton Cherokee sets, in a wide choice of colours. Try them on at our shop in Imenti House, Tom Mboya Street, or order online for same-day delivery in Nairobi and courier to any county in Kenya. Name embroidery is available on every set.',
	'jogger-scrubs'  => 'Jogger scrubs in Nairobi: Scrubstar Ultimate sets with a fitted stretch top and cuffed jogger trousers. Pick them up at Imenti House on Tom Mboya Street, or have them delivered the same day in Nairobi and by courier across Kenya.',
	'scrub-jackets'  => 'Scrub jackets for cold wards and early shifts: the Infinity warm-up jacket in soft stretch fabric with a full zip, made to match our scrub sets. Available at our Nairobi CBD shop, with delivery across Kenya and name embroidery on request.',
	'lab-coats'      => 'White lab coats in Nairobi for doctors, clinical officers, lab staff and medical students. Try one on at Imenti House, Tom Mboya Street, or order online with same-day Nairobi delivery. We can embroider your name and title on the chest.',
	'nurse-uniforms' => 'Nurse uniforms in Kenya: the white-and-navy uniform in the NCK style, white uniforms with or without buttons, and Chinese-collar tunics, sold as a full set or as a top or trousers on their own. In stock at our Nairobi CBD shop, with delivery countrywide.',
	'caps-layers'    => 'Theatre and nurse caps that fit long hair and braids, and soft pull-neck underscrubs for cold mornings. Order online or collect from Imenti House on Tom Mboya Street, Nairobi.',
	'footwear'       => 'Anti-slip medical clogs for wards and theatre: closed, easy to wipe clean and comfortable through a long shift. Available at our Nairobi CBD shop, with delivery across Kenya.',
	'stethoscopes'   => 'Stethoscopes in Nairobi: the 3M Littmann Classic II S.E. and Classic III, and a lightweight dual-head stethoscope for students. Collect from Imenti House on Tom Mboya Street or get same-day delivery in Nairobi.',
	'equipment'      => 'Medical equipment for students and clinicians in Kenya: manual and electronic BP machines, pulse oximeters, digital thermometers, pen torches, nurse fob watches and tape measures. In stock at our Nairobi CBD shop, with delivery countrywide.',
	'thrift-scrubs'  => 'Thrift (mtumba) scrubs in Nairobi: quality second-hand scrub sets in plain colours and prints, at a student-friendly price. Stock changes often, so visit Imenti House on Tom Mboya Street or WhatsApp us to see what is in.',
];

add_filter( 'term_description', function ( $text, $term_id = 0 ) {
	if ( trim( wp_strip_all_tags( (string) $text ) ) !== '' ) {
		return $text;
	}
	$term = $term_id ? get_term( $term_id ) : get_queried_object();
	if ( $term instanceof WP_Term && $term->taxonomy === 'product_cat' && isset( ASK_CAT_INTROS[ $term->slug ] ) ) {
		return '<p>' . esc_html( ASK_CAT_INTROS[ $term->slug ] ) . '</p>';
	}
	return $text;
}, 10, 2 );

function ask_seo_clip( $text, $max = 158 ) {
	$text = trim( preg_replace( '/\s+/', ' ', html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES, 'UTF-8' ) ) );
	if ( mb_strlen( $text ) <= $max ) {
		return $text;
	}
	$cut = mb_substr( $text, 0, $max );
	return rtrim( mb_substr( $cut, 0, mb_strrpos( $cut, ' ' ) ?: $max ), ' ,;:–-' ) . '…';
}

// Cheapest product in a category, for "from KSh …" in search results.
function ask_seo_from_price( WP_Term $term ) {
	$key = 'ask_from_' . $term->term_id;
	$min = get_transient( $key );
	if ( $min === false ) {
		$prices = array_filter( array_map(
			fn( $p ) => (float) $p->get_price(),
			wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'category' => [ $term->slug ] ] )
		) );
		$min = $prices ? min( $prices ) : 0;
		set_transient( $key, $min, 6 * HOUR_IN_SECONDS );
	}
	return (float) $min;
}

/**
 * What this page tells search engines and link previews.
 *
 * @return array{title: string, description: string, url: string, image: string, type: string, noindex: bool}
 */
function ask_seo() {
	static $seo;
	if ( $seo !== null ) {
		return $seo;
	}
	$hero = get_stylesheet_directory_uri() . '/assets/photos/hero-main.webp';
	$seo  = [ 'title' => '', 'description' => '', 'url' => '', 'image' => $hero, 'type' => 'website', 'noindex' => false ];

	if ( is_front_page() ) {
		$seo['title']       = 'Medical Scrubs in Nairobi, Kenya | ASK Scrubs';
		$seo['description'] = 'Buy medical scrubs in Nairobi: Infinity, Scrubstar and Cherokee scrub sets, lab coats, NCK nurse uniforms and Littmann stethoscopes. Same-day delivery in Nairobi.';
		$seo['url']         = home_url( '/' );
	} elseif ( is_search() ) {
		$seo['noindex'] = true;
	} elseif ( is_shop() ) {
		$seo['title']       = 'Shop Scrubs, Nurse Uniforms & Medical Equipment in Kenya | ASK Scrubs';
		$seo['description'] = 'All our scrubs, lab coats, nurse uniforms, stethoscopes and medical equipment in one place. Visit us at Imenti House, Nairobi CBD, or order for delivery anywhere in Kenya.';
		$seo['url']         = wc_get_page_permalink( 'shop' );
	} elseif ( is_product() ) {
		$product = wc_get_product( get_queried_object_id() );
		if ( $product ) {
			$price              = (float) ( $product->is_type( 'variable' ) ? $product->get_variation_price( 'max' ) : $product->get_price() );
			$seo['title']       = $product->get_name() . ( $price ? ' – KSh ' . number_format( $price ) : '' ) . ' | ASK Scrubs Nairobi';
			$seo['description'] = ask_seo_clip( $product->get_short_description() ?: $product->get_description() );
			$seo['url']         = $product->get_permalink();
			$seo['type']        = 'product';
			$seo['image']       = wp_get_attachment_image_url( $product->get_image_id(), 'large' ) ?: $hero;
		}
	} elseif ( is_tax() ) {
		$term = get_queried_object();
		$link = get_term_link( $term );
		$seo['url'] = is_wp_error( $link ) ? '' : $link;
		if ( $term->taxonomy === 'product_cat' ) {
			$from               = ask_seo_from_price( $term );
			$seo['title']       = $term->name . ' in Nairobi, Kenya | ASK Scrubs';
			$seo['description'] = ask_seo_clip( ( $from ? 'From KSh ' . number_format( $from ) . '. ' : '' ) . ( $term->description ?: ( ASK_CAT_INTROS[ $term->slug ] ?? '' ) ) );
		} elseif ( $term->taxonomy === 'pa_colour' ) {
			$seo['title']       = $term->name . ' Scrubs & Medical Uniforms in Nairobi | ASK Scrubs';
			$seo['description'] = 'Scrubs, jackets and uniforms in ' . strtolower( $term->name ) . ', in stock at ASK Scrubs, Imenti House, Nairobi CBD. Same-day delivery in Nairobi and courier across Kenya.';
		} elseif ( $term->taxonomy === 'product_tag' ) {
			$seo['title']       = 'Scrubs & Uniforms for ' . $term->name . ' in Kenya | ASK Scrubs';
			$seo['description'] = 'Scrubs, lab coats, uniforms and equipment picked for ' . strtolower( $term->name ) . '. Shop at Imenti House, Nairobi CBD, or order for delivery anywhere in Kenya.';
		} else {
			$seo['noindex'] = true; // Size pages repeat the shop page.
		}
	} elseif ( is_page( 'size-guide' ) ) {
		$seo['title']       = 'Scrubs Size Guide – Chest, Waist & Length | ASK Scrubs';
		$seo['description'] = 'Find your scrub size from XS to 3XL with our chest, waist and length chart, or visit our Nairobi CBD shop and try both sizes on.';
		$seo['url']         = get_permalink();
	} elseif ( is_cart() || is_checkout() || is_account_page() || is_page( 'wishlist' ) || is_404() ) {
		$seo['noindex'] = true;
	}

	if ( $seo['url'] && get_query_var( 'paged' ) > 1 ) {
		$seo['url'] = trailingslashit( $seo['url'] ) . 'page/' . (int) get_query_var( 'paged' ) . '/';
	}
	return $seo;
}

add_filter( 'pre_get_document_title', fn( $title ) => ask_seo()['title'] ?: $title, 20 );

add_filter( 'wp_robots', function ( $robots ) {
	if ( ask_seo()['noindex'] ) {
		unset( $robots['max-image-preview'] );
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}
	return $robots;
} );

add_action( 'wp_head', function () {
	$seo = ask_seo();
	if ( $seo['noindex'] || ! $seo['title'] ) {
		return;
	}
	echo '<meta name="description" content="' . esc_attr( $seo['description'] ) . "\">\n";
	if ( ! is_singular() ) { // WordPress prints the canonical link for single pages and products itself.
		echo '<link rel="canonical" href="' . esc_url( $seo['url'] ) . "\">\n";
	}
	$tags = [
		'og:site_name'   => 'ASK Scrubs',
		'og:locale'      => 'en_KE',
		'og:type'        => $seo['type'],
		'og:title'       => $seo['title'],
		'og:description' => $seo['description'],
		'og:url'         => $seo['url'],
		'og:image'       => $seo['image'],
	];
	foreach ( $tags as $property => $content ) {
		echo '<meta property="' . esc_attr( $property ) . '" content="' . esc_attr( $content ) . "\">\n";
	}
	echo "<meta name=\"twitter:card\" content=\"summary_large_image\">\n";

	if ( is_front_page() ) {
		$shop = [
			'@context'                  => 'https://schema.org',
			'@type'                     => 'ClothingStore',
			'@id'                       => home_url( '/#shop' ),
			'name'                      => 'ASK Scrubs',
			'description'               => $seo['description'],
			'url'                       => home_url( '/' ),
			'logo'                      => get_stylesheet_directory_uri() . '/assets/icon.png',
			'image'                     => $seo['image'],
			'telephone'                 => '+' . ASK_WHATSAPP,
			'priceRange'                => 'KSh',
			'currenciesAccepted'        => 'KES',
			'paymentAccepted'           => 'Cash, M-Pesa',
			'address'                   => [
				'@type'           => 'PostalAddress',
				'streetAddress'   => 'Imenti House, Limoda Exhibition, Shop 4DW Basement, Tom Mboya Street',
				'addressLocality' => 'Nairobi',
				'addressRegion'   => 'Nairobi County',
				'addressCountry'  => 'KE',
			],
			'areaServed'                => [ '@type' => 'Country', 'name' => 'Kenya' ],
			'openingHoursSpecification' => [ [
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => [ 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ],
				'opens'     => '08:00',
				'closes'    => '20:00',
			] ],
			'sameAs'                    => [ 'https://www.instagram.com/askscrubs.ke/', 'https://www.tiktok.com/@askscrubs_254' ],
		];
		$site = [
			'@context'        => 'https://schema.org',
			'@type'           => 'WebSite',
			'name'            => 'ASK Scrubs',
			'url'             => home_url( '/' ),
			'potentialAction' => [
				'@type'       => 'SearchAction',
				'target'      => home_url( '/?s={search_term_string}&post_type=product' ),
				'query-input' => 'required name=search_term_string',
			],
		];
		foreach ( [ $shop, $site ] as $data ) {
			echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
		}
	}
}, 2 );

// Photos uploaded without a description are described by the product they belong to.
add_filter( 'wp_get_attachment_image_attributes', function ( $attr, $attachment ) {
	if ( ! array_key_exists( 'alt', $attr ) || $attr['alt'] !== '' || str_contains( $attr['class'] ?? '', 'ask-alt-img' ) ) {
		return $attr;
	}
	if ( $attachment->post_parent && get_post_type( $attachment->post_parent ) === 'product' ) {
		$attr['alt'] = get_the_title( $attachment->post_parent );
	}
	return $attr;
}, 10, 2 );

// The sitemap lists what shoppers search for: products, categories, colours and roles.
add_filter( 'wp_sitemaps_add_provider', fn( $provider, $name ) => $name === 'users' ? false : $provider, 10, 2 );
add_filter( 'wp_sitemaps_taxonomies', function ( $taxonomies ) {
	unset( $taxonomies['pa_size'] );
	return $taxonomies;
} );
add_filter( 'wp_sitemaps_posts_query_args', function ( $args, $post_type ) {
	if ( $post_type === 'page' ) {
		$skip = array_filter( array_map( 'wc_get_page_id', [ 'cart', 'checkout', 'myaccount' ] ), fn( $id ) => $id > 0 );
		$wish = get_page_by_path( 'wishlist' );
		$args['post__not_in'] = array_merge( $args['post__not_in'] ?? [], $skip, $wish ? [ $wish->ID ] : [] );
	}
	return $args;
}, 10, 2 );

// Google Search Console checks this address to confirm who runs the site. Keep it.
add_action( 'init', function () {
	if ( strtok( $_SERVER['REQUEST_URI'] ?? '', '?' ) === '/google5d313fdec1997938.html' ) {
		header( 'Content-Type: text/html; charset=utf-8' );
		exit( 'google-site-verification: google5d313fdec1997938.html' );
	}
} );
